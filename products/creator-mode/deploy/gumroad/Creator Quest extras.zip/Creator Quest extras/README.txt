CREATOR QUEST EXTRAS (optional)
===============================

Everything here is already inside Creator Quest. You only need these files if you
want to insert model packs yourself or look at the backup scripts.

- Creator Vault: Roblox model packs (.rbxmx). In Studio, right-click Workspace >
  Insert from File > pick a pack. See Creator Vault/README.txt.
- Backup Scripts: the ready-made version of each big game.

Open Creator Quest: https://creator-quest.pages.dev
